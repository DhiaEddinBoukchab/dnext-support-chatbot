import pandas as pd
import numpy as np
from helpers.auth import connect
from helpers.custom import DataProcessor
import helpers.distance as dist
import requests
from io import BytesIO
import time


# Define a dictionary of products by chapter
products_chapter = {
    ## both oilseed and cereal chapters represented by '0' category
    '0': ['RICE','WHT', 'CRN', 'OAT', 'DWHT', 'BLY', 'RYE', 'SRG', 'SBO','POL','SFO','RSO'],
    '10': ['RICE','WHT', 'CRN', 'OAT', 'DWHT', 'BLY', 'RYE', 'SRG'],
    '12': ['SBO','POL','SFO','RSO']  ## Oil seeds
}
## Group countries by continents
east_asian_countries = ['China', 'Japan', 'South Korea', 'Taiwan', 'Mongolia', 'North Korea']
southeast_asian_countries = ['Indonesia', 'Thailand', 'Philippines', 'Malaysia', 'Singapore', 'Vietnam', 'Myanmar', 'Cambodia', 'Laos', 'Brunei', 'East Timor']
other_asian_countries = ['India', 'Kazakhstan', 'Pakistan', 'Bangladesh', 'Sri Lanka', 'Nepal', 'Bhutan', 'Maldives', 'Kyrgyzstan', 'Tajikistan', 'Uzbekistan', 'Turkmenistan', 'Afghanistan']
middle_eastern_countries = ['Saudi Arabia', 'Lebanon', 'Iran', 'Iraq', 'Syria', 'Jordan', 'Israel', 'Palestine', 'United Arab Emirates', 'Qatar', 'Bahrain', 'Kuwait', 'Oman', 'Yemen']
northern_europe = ['Norway', 'United Kingdom', 'Finland', 'Ireland', 'Iceland', 'Sweden', 'Denmark']
eu_countries = ['Germany', 'France', 'Italy', 'Spain', 'Netherlands', 'Belgium', 'Poland', 'Austria',  'Portugal', 'Greece', 'Czech Republic', 'Romania', 'Hungary', 'Slovakia', 'Bulgaria', 'Croatia', 'Slovenia', 'Lithuania', 'Latvia', 'Estonia', 'Cyprus', 'Luxembourg', 'Malta', 'Switzerland','Ukraine']
american_countries = ['United States', 'Canada', 'Mexico', 'Brazil', 'Argentina', 'Colombia', 'Chile', 'Peru', 'Venezuela', 'Ecuador', 'Guatemala', 'Paraguay', 'Bolivia']
african_countries = ['South Africa', 'Nigeria', 'Egypt', 'Algeria', 'Morocco', 'Kenya', 'Ethiopia', 'Ghana', 'Tanzania', 'Uganda', 'Zambia', 'Zimbabwe', 'Mozambique', 'Angola', 'Cameroon', 'Ivory Coast', 'Madagascar', 'Senegal', 'Sudan', 'Tunisia']
oceania_countries = ['Australia', 'New Zealand', 'Fiji', 'Papua New Guinea', 'Solomon Islands', 'Vanuatu', 'Samoa', 'Kiribati', 'Tonga', 'Tuvalu', 'Nauru', 'Palau', 'Marshall Islands', 'Micronesia']

# Load distance data and calculate ship period
distance = pd.read_csv('countries_fixed_features.csv')
distance['Ship_period'] = distance.apply(dist.calculate_travel_time_in_months, axis=1)

def authenticate_user(email, pwd, env):
    """ Authenticate user and return token. """
    return connect(email, pwd, env)


def _get_task_status(task_id, token):
    my_headers = {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json'
    }
    success = False
    wait_time = 2
    while not success and wait_time < 20:
        time.sleep(wait_time)

        status_res = requests.get(f'https://api.dnext.io/v1.0/tasks/{task_id}', headers=my_headers)
        try:
            success = status_res.json()['status'] == 'SUCCEEDED'
        except:
            wait_time += 1
            continue
        if not success:
            wait_time += 1
    if success:
        return True
    else:
        return False

def download_dataset(code, token):

    my_headers = {
    'Authorization': 'Bearer ' + token,
    'Content-Type': 'application/json'
    }

    dl_url = f'https://api.dnext.io/v1.0/data/datasets/{code}/download'

    res = requests.post(dl_url, headers=my_headers)
    print(res)
    print(res.json())
    task_id = res.json()['task']['id']

    data_ready = _get_task_status(task_id, token)

    if data_ready:
        data_url = res.json()['result']['url']
        data_resp = requests.get(data_url)
        df = pd.read_csv(BytesIO(data_resp.content))
    else:
        df = None
    return df

def load_data(dataset_code, email, pwd, env):
    token = authenticate_user(email, pwd, env)  
    df = download_dataset(dataset_code,token)
    return df

def adjust_month(row):
    """ 
    The date is udjusted with the round of the shipping period.
    For example if the shipping period is 1.7 months, the date is adjusted by 2 months.
    Args:
        row (Series): Row of the DataFrame.
        Returns:
        Series: Row with adjusted date.
    """
    if pd.isnull(row['Ship_period']):
        return row
    # Use Date to adjust month
    original_date = pd.to_datetime(row['Date Reporter'])
    # Calculate new date accounting for shipping period
    adjusted_date = original_date - pd.DateOffset(months=int(round(row['Ship_period'])))
    row['Date Reporter'] = adjusted_date.strftime('%Y-%m-%d')
    return row

def compute_ratio(row):
    ## This needs to take into consideration the direction of the trade ..
    """ Compute the ratio of imports to exports in percentage. 
    Args:
        row (Series): Row of the DataFrame.
    Returns:
        float: Ratio of imports to exports in percentage.
    """
    if row['Total Quantity_exp'] == 0 and row['Total Quantity_imp'] == 0:
        return 0
    else:
        return row['Diff'] / max(row['Total Quantity_exp'], row['Total Quantity_imp'])

def manual_mad(series):
    """Calculate the Mean Absolute Deviation of a series."""
    return (series - series.median()).abs().median()


def calculate_stats_discrepancy(df, group_by='Country_Name'):
    """Calculate median and mad for 'Diff' and 'Ratio' for each country."""
    agg_dict = {
        'Diff': [
            ('median', 'median'),
            ('mad', lambda x: manual_mad(x))
        ],
        'Ratio': [
            ('median', 'median'),
            ('mad', lambda x: manual_mad(x))
        ]
    }
    stats = df.groupby(group_by).agg(agg_dict).reset_index()
    
    if isinstance(group_by, str):
        stats.columns = [group_by, 'Diff_median', 'Diff_mad', 'Ratio_median', 'Ratio_mad']
    else:
        stats.columns = [group_by[0], group_by[1], 'Diff_median', 'Diff_mad', 'Ratio_median', 'Ratio_mad']
    
    return stats

def detect_anomalies_diff(df, stats, num_std_dev=1, group_by=['Country_Name','Product']):
    """
    Detect anomalies based on the difference between imports and exports.
    
    Args:
        df: DataFrame with trade data
        stats: DataFrame with precomputed statistics
        num_std_dev: Number of standard deviations to use for anomaly detection
        group_by: Column(s) used for grouping
        
    Returns:
        DataFrame with anomaly flags and thresholds
    """
    df = df.merge(stats, on=group_by)
    df['Diff_Anomaly'] = df.apply(lambda x: abs(x['Diff'] - x['Diff_median']) > num_std_dev * x['Diff_mad'], axis=1)
    df['Threshold_Diff'] = num_std_dev * df['Diff_mad']
    return df


def detect_anomalies(df,threshold=0.25,group_by=['Country_Name','Product']):
    """
    Summarize DIFF anomalies by destination: count, when, and how much.
    Args:
        df (DataFrame): DataFrame after anomaly detection.
    Returns:
        DataFrame: Summary table with destination, count, dates, and anomaly values.
    """
    # Filter only DIFF anomalies
    df['Anomaly'] = df.apply(lambda x: abs(x['Ratio']) > threshold, axis=1)
    return df[df['Anomaly'] == True]

    
def calculate_discrepancies_by_product_chapter(df,group_by=['Product_Chapter','Country_Name']):
    """
    Group data by year and country group and calculate ratio.
    """

    # Group data by date and product group
    grouped = df.groupby(['Date Reporter']+group_by).agg({
        'Total Quantity_exp': 'sum',
        'Total Quantity_imp': 'sum',
        'Diff': 'sum'
    }).reset_index()
    
    # Calculate the Ratio as Diff / max(Total Quantity_exp, Total Quantity_imp)
    grouped['Ratio'] = grouped.apply(compute_ratio, axis=1)
    return grouped

def calculate_discrepancies_by_country_group(df,group_by=['Country_Group','Product']):
    """
    Group data by year and country group and calculate ratio.
    """
    # Group data by year and country group
    grouped = df.groupby(['Date Reporter']+group_by).agg({
        'Total Quantity_exp': 'sum',
        'Total Quantity_imp': 'sum',
        'Diff': 'sum'
    }).reset_index()
    
    # Calculate the Ratio as Diff / max(Total Quantity_exp, Total Quantity_imp)
    grouped['Ratio'] = grouped.apply(compute_ratio, axis=1)
    return grouped
def group_by_timeframe(df, time_freq='ME', group_by=['Country_Name','Product']):
    """
    Adjust the time frequency of the DataFrame.
    Args:
        df (DataFrame): DataFrame to adjust.
        time_freq (str): Time frequency ('M', 'Q', 'Y').
    Returns:
        DataFrame: Adjusted DataFrame.
    """
    df['Date Reporter'] = pd.to_datetime(df['Date Reporter'])
    
    if isinstance(group_by, str):
        grouping_columns = [pd.Grouper(key='Date Reporter', freq=time_freq), group_by]
    else:
        grouping_columns = [pd.Grouper(key='Date Reporter', freq=time_freq), group_by[0], group_by[1]]
    # Group data by the timeframe
    df = df.groupby(grouping_columns).agg({
        'Total Quantity_exp': 'sum',
        'Total Quantity_imp': 'sum',
        'Diff': 'sum'
    }).reset_index()
    
    df['Ratio'] = df.apply(compute_ratio, axis=1)
    return df

def Mirror(df,country='Brazil', product_class='0', time_freq='ME', group_by=['Country_Name','Product']):
    """
    Main function to load data, merge, and plot it based on various criteria.
    Args:
        country (str): Country of interest.
        product_class (str): Product class code.
        product (str): Specific product.
        time_freq (str): Time frequency for data aggregation ('M', 'Q', 'Y').
        group_by (str): Grouping criterion ('destination', 'product', 'total').
    Returns:
        DataFrame: Merged data with discrepancies.
    """
    

    if df is not None:
        exports = DataProcessor.process_data(df, 'Export', country)
        imports = DataProcessor.process_data(df, 'Import', country)
    
        exports = exports[exports['Product'].isin(products_chapter[product_class])]
        imports = imports[imports['Product'].isin(products_chapter[product_class])]

        # Add shipment period from Brazil to the partners
        distance_x = distance[distance['name_o'] == country]
        #exports = exports.merge(distance_x[['name_d', 'Ship_period']], left_on='Country_Name', right_on='name_d', how='left')
        imports = imports.merge(distance_x[['name_d', 'Ship_period']], left_on='Country_Name', right_on='name_d', how='left')
        imports = imports.apply(adjust_month, axis=1)
        #drop the name_d column
        imports.drop(columns=['name_d', 'Ship_period'], inplace=True)
        ## Group by the date
        exports['Date Reporter'] = pd.to_datetime(exports['Date Reporter'])
        imports['Date Reporter'] = pd.to_datetime(imports['Date Reporter'])
        # Setting up grouping columns based on user input
        grouping_columns = [pd.Grouper(key='Date Reporter', freq=time_freq), group_by[0], group_by[1]]
       
        exports_agg = exports.groupby(grouping_columns).agg({'Total Quantity': 'sum'}).reset_index()
        imports_agg = imports.groupby(grouping_columns).agg({'Total Quantity': 'sum'}).reset_index()
        # Merge exports and imports data
        merged_data = pd.merge(exports_agg, imports_agg, how="outer",on=['Date Reporter']+group_by, suffixes=('_exp', '_imp'))
        ## When one party (Importer or exporter ) reports but the other doesn't keep it as NaN.
        merged_data['Diff'] = merged_data['Total Quantity_imp'] - merged_data['Total Quantity_exp']
        merged_data['Abs_Diff'] = merged_data['Diff'].abs()
        merged_data['Ratio'] = merged_data.apply(lambda row: compute_ratio(row) if pd.notna(row['Diff']) else np.nan, axis=1)
        merged_data['Product_Chapter'] = merged_data['Product'].apply(lambda x: 
        '10' if x in products_chapter['10'] else '12')
           # Assign countries to groups
        merged_data['Country_Group'] = merged_data['Country_Name'].apply(lambda x: 
        'East Asia' if x in east_asian_countries else 
        ('Southeast Asia' if x in southeast_asian_countries else 
        ('Other Asian Countries' if x in other_asian_countries else 
        ('Middle East' if x in middle_eastern_countries else 
        ('Northern Europe' if x in northern_europe else
        ('EU Countries' if x in eu_countries else 
        ('America' if x in american_countries else 
        ('Africa' if x in african_countries else 
        ('Oceania' if x in oceania_countries else 
        'Other')))))))))
        merged_data['Date Reporter'] = pd.to_datetime(merged_data['Date Reporter'])


        return merged_data





 
def top_partners_by_cat(df_Y, threshold=0.05):
    top_partners_by_category = {}
    categories = ['10', '12', 'CRN'] 
    for category in categories:
        if category == 'CRN':
            # Filter FOR CORN
            df_cat = df_Y[df_Y['Product'] == 'CRN']
        else:
            # Filter for oilseeds or celreals
            df_cat = df_Y[df_Y['Product_Chapter'] == category]


        # Calculate total quantity per year for that category
        year_total = df_cat.groupby('Date Reporter')['Total Quantity_exp'].sum().reset_index(name='Year_Total_Quantity')

        # Merge year total back
        df_cat = df_cat.merge(year_total, on='Date Reporter', how='left')

        # Compute partner share
        df_cat['Partner_Share'] = df_cat['Total Quantity_exp'] / df_cat['Year_Total_Quantity']
        important_partners = df_cat[df_cat['Partner_Share'] >= threshold]['Country_Name'].unique()
        top_partners_by_category[category] = important_partners.tolist()
    return top_partners_by_category