import json 
import requests

# Login to API and get token
def connect(email, pwd, env):

    ''' email: email used to connect to your dnext environment
    pwd: password
    env: name of your enviroment, first part in your dnext URL before the dot
    ENV.dnext.io -> env = 'ENV' '''


    # Login to API and get token
    url = f'https://api.dnext.io/v1.0/auth/custom-login?org={env}'

    payload = json.dumps (
        {
            'email': f'{email}',
            'password': f'{pwd}',
            'organization':f'{env}'
        }
    )
    headers= {
        'Content-Type': 'application/json'
    }

    response  = requests.post(url, headers=headers, data=payload)
    token = response.json()['token']

    return token


