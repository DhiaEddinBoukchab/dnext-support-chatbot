import pandas as pd

class DataProcessor:

    @staticmethod
    def process_data(data, trade_direction, country_name):
        """Processes data for exports or imports based on the trade direction."""
        if trade_direction == 'Export':
            x = 'Country Reporter_MappedName'
            relevant_country_column = 'Country Partner_MappedName'
        elif trade_direction == 'Import':
            x = 'Country Partner_MappedName'
            relevant_country_column = 'Country Reporter_MappedName'
        else:
            print("Invalid trade direction specified.")
            return None

        data = data[(data['Trade Direction'] == trade_direction) & (data[x] == country_name)]

        

        # Convert date column to datetime
        data['Date Reporter'] = pd.to_datetime(data['Date Reporter'])

        # Define aggregation based on the specified time frequency
        aggregation_columns = ['Date Reporter', relevant_country_column, 'Product']
        data['Total Quantity'] = data['Quantity Unit multiplier'] * data['Quantity'] / 1000
        
        # Group data based on the new aggregation columns
        data_aggregated = data.groupby(aggregation_columns)['Total Quantity'].sum().reset_index()
        data_aggregated.rename(columns={relevant_country_column: 'Country_Name'}, inplace=True)

        return data_aggregated
