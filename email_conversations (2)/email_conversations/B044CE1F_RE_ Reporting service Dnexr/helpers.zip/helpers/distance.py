## This function is to calculate the distance between two points in months. We suppose that minimum speed for a ship is 12 km/h. 
## The distance is in KM.
def calculate_travel_time_in_months(row, speed=12):
    # Calculate time using minimum speed
    time = row['Distw'] / speed
    # Convert time from hours to months
    time = time / (24*30)
    return time