from plotly.subplots import make_subplots
import plotly.graph_objs as go
import pandas as pd
import plotly.express as px
from IPython.display import Image, display
import os
import helpers.Mirror_view as Mirror_view

def compute_discrepancy_metrics(df, group_col):
    agg = df.groupby(group_col).agg(
        total_imp=('Total Quantity_imp', 'sum'),
        total_exp=('Total Quantity_exp', 'sum')
    ).reset_index()
    agg['Accumulated_Diff'] = agg['total_imp'] - agg['total_exp']
    agg['Max_Imp_Exp'] = agg[['total_imp', 'total_exp']].max(axis=1)
    agg['Accumulated_Ratio'] = agg.apply(
        lambda row: 0 if row['Max_Imp_Exp'] == 0 else row['Accumulated_Diff'] / row['Max_Imp_Exp'], axis=1
    )
    return agg



def prepare_heatmap_and_text(df, index_col, columns_col, value_col, annotation_col):
    """
    Prepare data for heatmap visualization with annotations.
    
    Args:
        df: Input DataFrame
        index_col: Column to use as index
        columns_col: Column to use as columns
        value_col: Column containing values for heatmap
        annotation_col: Column containing annotation values
        
    Returns:
        Tuple of (heatmap_data, annotation_data)
    """
    heatmap = df.pivot_table(index=index_col, columns=columns_col, values=value_col)
    text = df.pivot_table(index=index_col, columns=columns_col, values=annotation_col)
    text = text.map(lambda x: f"{float(x):.0f}" if not pd.isna(x) else "")
    return heatmap, text

def plot_discrepancy(heatmap, text_data, agg, x_bar, y_bar, title, output_file=None):
    """
    Create a combined heatmap and bar chart visualization for discrepancy analysis.
    
    Args:
        heatmap: Heatmap data
        text_data: Annotation data for heatmap
        agg: Aggregated data for bar chart
        x_bar: X-axis column for bar chart
        y_bar: Y-axis column for bar chart
        title: Plot title
        output_file: Optional path to save the figure
        
    Returns:
        Plotly figure object
    """    
    heatmap.index = pd.to_datetime(heatmap.index).year
    text_data.index = heatmap.index

    fig = make_subplots(
        rows=2, cols=1,
        vertical_spacing=0.2,
        subplot_titles=('Heatmap of Ratio (Text = Diff)', 'Over Time'),
        row_heights=[0.8, 0.2]
    )

    # Add heatmap
    fig.add_trace(
        go.Heatmap(
            z=heatmap.values,
            x=heatmap.columns,
            y=heatmap.index,
            showscale=True,
            text=text_data.values,
            texttemplate="%{text}",
            hoverinfo="text",
            colorscale='Viridis',
            textfont=dict(size=7),
            zmin=-1,
            zmax=1
        ),
        row=1, col=1
    )

    # Add bar chart
    fig.add_trace(
        go.Bar(
            x=agg[x_bar],
            y=agg[y_bar],
            marker_color='indianred'
        ),
        row=2, col=1
    )

    fig.update_layout(
        height=800,
        width=1200,
        showlegend=False,
        title_text=title,
        font=dict(size=10),
        margin=dict(l=50, r=50, t=50, b=50)
    )

    fig.update_yaxes(title_text="Year", row=1, col=1)
    fig.update_xaxes(title_text=x_bar, row=2, col=1)
    fig.update_yaxes(title_text="Ratio", range=[-1, 1], row=2, col=1)

    if output_file:
        save_figure_as_image(fig, output_file)

    return fig

def analyze_by_group(df, product_filter, product_key, top_partners, value_label, reporter, output_dir=None):
    """
    Analyze trade data by country groups.
    
    Args:
        df: Input DataFrame
        product_filter: Filter condition for products
        product_key: Key for top partners dictionary
        top_partners: Dictionary of top trading partners
        value_label: Label for the analysis
        reporter: Reporter country name
        output_dir: Optional output directory for saving figures
        
    Returns:
        Plotly figure object
    """
    df_product = df[product_filter]
    df_product = df_product[df_product['Country_Name'].isin(top_partners[product_key])]
    df_product = df_product.dropna(subset=['Diff'])
    
    df_group = Mirror_view.calculate_discrepancies_by_country_group(df_product)
    heatmap, text = prepare_heatmap_and_text(df_group, "Date Reporter", "Country_Group", "Ratio", "Diff")
    agg = compute_discrepancy_metrics(df_group, "Country_Group")
    agg = agg[agg['Country_Group'].isin(heatmap.columns)]

    output_file = f'outputs/{output_dir}/{value_label}_groupofcountries.png' if output_dir else None
    return plot_discrepancy(
        heatmap, text, agg,
        x_bar="Country_Group",
        y_bar="Accumulated_Ratio",
        title=f"{reporter}: Ratio per Group of countries for {value_label}",
        output_file=output_file
    )

def analyze_by_product_axis(df, axis_col, value_label, reporter, output_dir=None):
    """
    Analyze trade data by product axis.
    
    Args:
        df: Input DataFrame
        axis_col: Column to use as analysis axis
        value_label: Label for the analysis
        reporter: Reporter country name
        output_dir: Optional output directory for saving figures
        
    Returns:
        Plotly figure object
    """
    heatmap, text = prepare_heatmap_and_text(df, "Date Reporter", axis_col, "Ratio", "Diff")
    df = df.dropna(subset=['Diff'])
    agg = compute_discrepancy_metrics(df, axis_col)
    agg = agg[agg[axis_col].isin(heatmap.columns)]
    
    heatmap.columns = heatmap.columns.astype(str)
    text.columns = heatmap.columns
    agg[axis_col] = agg[axis_col].astype(str)

    output_file = f'outputs/{output_dir}/per{axis_col.lower()}.png' if output_dir else None
    return plot_discrepancy(
        heatmap, text, agg,
        x_bar=axis_col,
        y_bar="Accumulated_Ratio",
        title=f"{reporter}: Ratio per {value_label}",
        output_file=output_file
    )

def analyze_bydestination(df, product_filter, product_key, top_partners, label, reporter, output_dir=None):
    """Modified to support PDF export"""
    df_product = df[product_filter]
    df_product = df_product[df_product['Country_Name'].isin(top_partners[product_key])]
    heatmap, text = prepare_heatmap_and_text(df_product, "Date Reporter", "Country_Name", "Ratio", "Diff")
    
    df_product = df_product[df_product['Country_Name'].isin(heatmap.columns)]
    df_product = df_product.dropna(subset=['Diff'])
    
    yearly_totals = df_product.groupby('Date Reporter').agg(
        total_imp=('Total Quantity_imp', 'sum'),
        total_exp=('Total Quantity_exp', 'sum'),
        Total_Diff=('Diff', 'sum')
    ).reset_index()
    
    yearly_totals['Max_Imp_Exp'] = yearly_totals[['total_imp', 'total_exp']].max(axis=1)
    yearly_totals['Total_Ratio'] = yearly_totals.apply(
        lambda row: 0 if row['Max_Imp_Exp'] == 0 else row['Total_Diff'] / row['Max_Imp_Exp'], axis=1
    )
    
    heatmap['Total Destination'] = yearly_totals.set_index('Date Reporter')['Total_Ratio']
    text['Total Destination'] = yearly_totals.set_index('Date Reporter')['Total_Diff'].apply(lambda x: f"{float(x):.0f}")

    agg = compute_discrepancy_metrics(df_product, "Country_Name")
    agg = agg[agg['Country_Name'].isin(heatmap.columns)]
    
    total_destination_diff = yearly_totals['Total_Diff'].sum()
    total_destination_max = yearly_totals['Max_Imp_Exp'].sum()
    total_destination_ratio = 0 if total_destination_max == 0 else total_destination_diff / total_destination_max

    agg = pd.concat([
        agg,
        pd.DataFrame([{
            'Country_Name': 'Total Destination',
            'total_imp': yearly_totals['total_imp'].sum(),
            'total_exp': yearly_totals['total_exp'].sum(),
            'Accumulated_Diff': total_destination_diff,
            'Max_Imp_Exp': total_destination_max,
            'Accumulated_Ratio': total_destination_ratio
        }])
    ])

    output_file = f'outputs/{output_dir}/{label.lower()}_perdestination.png' if output_dir else None
    return plot_discrepancy(
        heatmap, text, agg,
        x_bar="Country_Name",
        y_bar="Accumulated_Ratio",
        title=f"{reporter}: {label} Ratio by Country",
        output_file=output_file
    )

def create_heatmap(df, x_col, y_col, value_col, title, colorscale='viridis'):
    """
    Create a plotly heatmap with improved export compatibility
    """
    fig = go.Figure(data=go.Heatmap(
        z=df[value_col],
        x=df[x_col],
        y=df[y_col],
        colorscale=colorscale,
        hoverongaps=False,
        hovertemplate='%{y}<br>%{x}<br>Value: %{z}<extra></extra>'
    ))
    
    fig.update_layout(
        title=title,
        xaxis_title=x_col,
        yaxis_title=y_col,
        font=dict(size=10),
        height=600,
        width=1000,
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    return fig

def create_bar_chart(df, x_col, y_col, title, color_col=None):
    """
    Create a plotly bar chart with improved export compatibility
    """
    if color_col:
        fig = px.bar(df, x=x_col, y=y_col, color=color_col, title=title)
    else:
        fig = px.bar(df, x=x_col, y=y_col, title=title)
    
    fig.update_layout(
        font=dict(size=10),
        height=500,
        width=800,
        margin=dict(l=50, r=50, t=50, b=50)
    )
    
    return fig

def save_figure_as_image(fig, filename, format='png'):
    """Save a plotly figure as a static image using kaleido"""
    try:
        fig.write_image(filename, format=format, engine='kaleido', scale=2.0)
    except Exception as e:
        print(f"Warning: Could not save figure to {filename}: {str(e)}")



def display_saved_figure(filename):
    """Display a saved figure if it exists, otherwise show warning"""
    if os.path.exists(filename):
        display(Image(filename=filename))
    else:
        print(f"Warning: Figure {filename} not found")